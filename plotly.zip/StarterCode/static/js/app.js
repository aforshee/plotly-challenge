//Data Source
jsonfile = 'samples.json'
  
// Promise Pending
const dataPromise = d3.json(jsonfile);
console.log("Data Promise: ", dataPromise);


//create function that will grab data and build charts
function buildCharts(sample) {
  d3.json(jsonfile).then((data) => {

    // Grab values from the data json object to build the plots
    var names = data.names;
    var samples = data.samples;
    var resultArray = samples.filter(sampleObj => sampleObj.id == sample);
    var otu_ids = resultArray.otu_ids;
    var otu_labels = resultArray.otu_labels;
    var sample_values = resultArray.sample_values;
    console.log(names);
    console.log(samples);
    console.log(resultArray);
    console.log(otu_ids)
    console.log(otu_labels)
    console.log(sample_values)
    });
  }
  buildCharts()